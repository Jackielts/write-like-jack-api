const express = require('express');
const app = express();
const port = 3000;

// Allow JSON in requests
app.use(express.json());

// POST route to handle essay feedback
app.post('/api/analyse', (req, res) => {
  const essay = req.body.essay; // Get the essay from the request body

  if (!essay) {
    return res.status(400).json({ error: 'No essay provided.' });
  }

  // Fake feedback for now (replace with real logic later)
  const feedback = {
    ta: 'Task Achievement: Excellent',
    cc: 'Coherence and Cohesion: Good',
    lr: 'Lexical Resource: Average',
    grammar: 'Grammar: Needs improvement',
    bandScore: 'Predicted Band: 7'
  };

  res.json(feedback); // Respond with the feedback
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
